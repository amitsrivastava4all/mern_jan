const config = {
    URL :'https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q='
}
const makeURL=(searchValue)=>
     config.URL+searchValue+"&limit=5";
