const expenseOperations = {
    expenses:[],
    add(expenseObject){
        let expObj = createExpenseObject(expenseObject);
        this.expenses.push(expObj);
    },
    getTotal(){
        return this.expenses.length;
    },
    countUnMark(){
       return  this.getTotal() - this.countMarked();
    },
    countMarked(){
        return this.expenses.filter(expense=>expense.isMarked).length;
    },
    toggleMark(id){
        let expObject = this.findById(id);
        if(expObject){
            expObject.isMarked = !expObject.isMarked;
        }
    },
    findById(id){
        return this.expenses.find(expense=>expense.id==id);
    }
}
