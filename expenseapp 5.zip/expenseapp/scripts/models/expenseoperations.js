const expenseOperations = {
    expenses:[],
    add(exp){
       // let expObj = createExpenseObject(expenseObject);
       let expenseObject = new Expense(exp.id, exp.name,exp.cost, exp.date,exp.remarks, exp.url);
        this.expenses.push(expenseObject);
    },
    resetExpenses(){
        this.expenses = [];
    },
    getExpenses(){
        return this.expenses;
    },
    remove(){
        this.expenses = this.expenses.filter(expense=>!expense.isMarked)
    },
    sort(){
        this.expenses.sort((first, second)=>first.cost - second.cost);
    },
    getTotal(){
        return this.expenses.length;
    },
    countUnMark(){
       return  this.getTotal() - this.countMarked();
    },
    countMarked(){
        return this.expenses.filter(expense=>expense.isMarked).length;
    },
    toggleMark(id){
        let expObject = this.findById(id);
        if(expObject){
            expObject.isMarked = !expObject.isMarked;
        }
    },
    findById(id){
        return this.expenses.find(expense=>expense.id==id);
    }
}
