function doAjax(searchValue){
    const promise = fetch(makeURL(searchValue));
    //fetch(URL); // GET Call
    /*fetch(URL,{
        method:'POST',
        body:JSON.stringify({userid:'ram',pwd:1111})
    });*/

    return promise;
}