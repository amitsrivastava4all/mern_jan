 window.addEventListener('load',init);

 function init(){
     bindEvents();
     countUpdates();
 }

// bindEvents();
function bindEvents(){
    document.querySelector('#add')
    .addEventListener('click',add);
}

// (function (){
//         document.querySelector('#add')
//         .addEventListener('click',readDOM);
//     })();
function add(){
    const expenseObject = readDOM();
    expenseOperations.add(expenseObject);
    printExpense(expenseObject);
    countUpdates();
    //createExpenseObject(expenseObject);
}

function countUpdates(){
    document.querySelector('#total').innerText =
    expenseOperations.getTotal();

    document.querySelector('#mark').innerText =
     expenseOperations.countMarked();
    document.querySelector('#unmark').innerText =
    expenseOperations.countUnMark();
}

function toggleMark(){
    console.log('What is ',this);
    let id = this.getAttribute('data-eid');
    expenseOperations.toggleMark(id);
    countUpdates();
    let tr= this.parentNode.parentNode;
    //tr.className = 'alert-danger';
    tr.classList.toggle('alert-danger');
}

function edit(){

}

function createIcon(className,fn,id){
    // <i class="fas fa-user-edit" onclick="edit()"></i>
    //<i class="fas fa-trash" onclick="toggleMark()"></i>
    let icon = document.createElement('i');
    icon.className = className;
    icon.addEventListener('click',fn);
    icon.setAttribute('data-eid',id);
    return icon;
}


function printExpense(expenseObject){
    let tbody = document.querySelector('#expenses');
    let tr = tbody.insertRow();
    let index = 0;
    for(let key in expenseObject){
    let td = tr.insertCell(index);
    index++;
    td.innerText = expenseObject[key];
    }
    let td = tr.insertCell(index);
    td.appendChild(createIcon('fas fa-user-edit',edit
    ,expenseObject.id));
    td.appendChild(createIcon('fas fa-trash',toggleMark,
    expenseObject.id));


}

function readDOM(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let date = document.querySelector('#date').value;
    let remarks = document.querySelector('#remarks').value;
    let url = document.querySelector('#url').value;
    const obj = {id, name, cost, date, remarks , url};
    return obj;
    //console.log(id, name, cost, date, remarks , url);
}