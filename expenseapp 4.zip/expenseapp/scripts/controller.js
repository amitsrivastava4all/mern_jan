 window.addEventListener('load',init);

 function init(){
     bindEvents();
     countUpdates();
     load();
 }

// bindEvents();
function bindEvents(){
    document.querySelector('#add')
    .addEventListener('click',add);
    document.querySelector('#remove').addEventListener('click',remove);
    document.querySelector('#save').addEventListener('click',save);
    document.querySelector('#load').addEventListener('click',load);
    document.querySelector('#sort').addEventListener('click',sort);
    document.querySelector('#update').addEventListener('click',update);
    document.querySelector('#clear').addEventListener('click',()=>{
        localStorage.clear();
        expenseOperations.resetExpenses();
        printExpenses();
    });
    }

    function update(){
        var obj = readDOM();
        for(let key in obj){
            expenseObject[key] = obj[key];
        }
        printExpenses();
    }

    function sort(){
        expenseOperations.sort();
        printExpenses();
    }
function load(){
    if(window.localStorage){
        if(localStorage.expenses){
            let expenses = JSON.parse(localStorage.expenses);
            expenses.forEach(expense=>expenseOperations.add(expense));
            printExpenses();

        }
        else{
            alert("Nothing to Load...");
        }
    }
    else{
        alert('Ur browser is outdated no support of localstorage');
    }
}
function save(){
    if(window.localStorage){
        let jsonString = JSON.stringify(expenseOperations.getExpenses());
        localStorage.expenses = jsonString;
        alert('Data Saved...');
    }
    else{
        alert('Ur browser is outdated no support of localstorage');
    }
}
function remove(){
    expenseOperations.remove();
    printExpenses();

}

function printExpenses(){
    document.querySelector('#expenses').innerHTML = '';
    let expenses = expenseOperations.getExpenses();
    expenses.forEach(printExpense);
    countUpdates();
}

// (function (){
//         document.querySelector('#add')
//         .addEventListener('click',readDOM);
//     })();
function add(){
    const expenseObject = readDOM();
    expenseOperations.add(expenseObject);
    printExpense(expenseObject);
    countUpdates();
    //createExpenseObject(expenseObject);
}

function countUpdates(){
    document.querySelector('#total').innerText =
    expenseOperations.getTotal();

    document.querySelector('#mark').innerText =
     expenseOperations.countMarked();
    document.querySelector('#unmark').innerText =
    expenseOperations.countUnMark();
}

function toggleMark(){
    console.log('What is ',this);
    let id = this.getAttribute('data-eid');
    expenseOperations.toggleMark(id);
    countUpdates();
    let tr= this.parentNode.parentNode;
    //tr.className = 'alert-danger';
    tr.classList.toggle('alert-danger');
}
let expenseObject ;
function edit(){
    let id = this.getAttribute('data-eid');
    expenseObject = expenseOperations.findById(id);
    for(let key in expenseObject){
        if(key=='isMarked' ){
            continue;
        }
        document.querySelector(`#${key}`).value = expenseObject[key];
    }
}

function createIcon(className,fn,id){
    // <i class="fas fa-user-edit" onclick="edit()"></i>
    //<i class="fas fa-trash" onclick="toggleMark()"></i>
    let icon = document.createElement('i');
    icon.className = className;
    icon.addEventListener('click',fn);
    icon.setAttribute('data-eid',id);
    return icon;
}


function printExpense(expenseObject){
    let tbody = document.querySelector('#expenses');
    let tr = tbody.insertRow();
    let index = 0;
    for(let key in expenseObject){
        if(key=='isMarked'){
            continue;
        }
    let td = tr.insertCell(index);
    index++;
    td.innerText = expenseObject[key];
    }
    let td = tr.insertCell(index);
    td.appendChild(createIcon('fas fa-user-edit',edit
    ,expenseObject.id));
    td.appendChild(createIcon('fas fa-trash',toggleMark,
    expenseObject.id));


}

function readDOM(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let date = document.querySelector('#date').value;
    let remarks = document.querySelector('#remarks').value;
    let url = document.querySelector('#url').value;
    const obj = {id, name, cost, date, remarks , url};
    return obj;
    //console.log(id, name, cost, date, remarks , url);
}