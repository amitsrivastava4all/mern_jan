
function  Expense(id , name, cost, date,remarks, url){
    this.id = id;
    this.name = name;
    this.cost = cost;
    this.date = date;
    this.remarks = remarks ;
    this.url = url;
    this.isMarked  = false;
}

// function createExpenseObject(expenseObject){
//     //const expense = expenseObject;
//     const expense = {};
//     for(let key in expenseObject){
//         expense[key] = expenseObject[key];
//     }
//     expense.isMarked =false;

//     // expense.id = id;
//     // expense.name = name;
//     // expense.cost = cost;
//     // expense.date = date;
//     // expense.remarks = remarks;
//     // expense.url = url;
//     return expense;
// }