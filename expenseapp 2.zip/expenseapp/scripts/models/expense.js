function createExpenseObject(expenseObject){
    //const expense = expenseObject;
    const expense = {};
    for(let key in expenseObject){
        expense[key] = expenseObject[key];
    }
    expense.isMarked =false;

    // expense.id = id;
    // expense.name = name;
    // expense.cost = cost;
    // expense.date = date;
    // expense.remarks = remarks;
    // expense.url = url;
    return expense;
}