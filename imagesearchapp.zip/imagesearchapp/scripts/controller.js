window.addEventListener('load',init);
function init(){
    document.querySelector('#searchbutton')
    .addEventListener('click', search);
}

function search(){
    let searchValue = document.querySelector('#searchtxt')
    .value;
    //fetch(makeURL(searchValue),{method:'GET'});
    doAjax(searchValue).then(response=>{
        response.json().
        then(data=>print(data))
        .catch(err=>printError(err)); // JSON parse Error
    }).catch(err=>printError(err)); // Server Error
}
function print(jsonResponse){
let div = document.querySelector('#result');
div.innerHTML = '';
jsonResponse.data.forEach((element)=>{
    let img = document.createElement('img');
    img.src = element.images.original.url;
    img.className='size';
    div.appendChild(img);
})

}
function printError(err){

}